import { EventEmitter } from 'events';

declare class Sequence extends EventEmitter {}

export { Sequence };
